﻿#include <SFML/Graphics.hpp>
#include <iostream>
#include <ctime>
#include <random>
using namespace sf;

const int WYS_MARG = 25;
const int SZER_MARG = 12;

const int bok = 4;

const int tetromino[7][bok * bok] =
{
	{
		0,0,1,0,
		0,0,1,0,		// Pasek pionowy
		0,0,1,0,
		0,0,1,0
	},
	{
		0,0,0,0,
		0,1,1,0,
		0,0,1,0,
		0,0,1,0			// L
	},
	{
		0,0,0,0,
		0,1,1,0,
		0,1,0,0,		// odwrócone L
		0,1,0,0
	},
	{
		0,0,0,0,
		0,1,0,0,
		0,1,1,0,		// S
		0,0,1,0
	},
	{
		0,0,0,0,
		0,0,1,0,
		0,1,1,0,		// Z
		0,1,0,0
	},
	{
		0,0,0,0,
		0,0,1,0,		// T
		0,1,1,0,
		0,0,1,0
	},
	{
		0,0,0,0,
		0,0,0,0,
		0,1,1,0,		// kwadrat
		0,1,1,0
	}
};

struct Punkt
{
	int x, y;
} a[4], offset;

std::random_device rd;
std::mt19937 gen(rd());
std::uniform_int_distribution<> dist(0, 6);

int n = dist(gen);

bool check_collison_left(Punkt* tab, int* POLE_GRY, Punkt offset)
{
	int suma_konrotlna = 0;
	for (int i = 0; i < bok; i++)
	{
		Punkt punkt_globalny = { a[i].x + offset.x, a[i].y + offset.y };
		if (POLE_GRY[(punkt_globalny.y) * SZER_MARG + punkt_globalny.x] != 8)
			suma_konrotlna++;
	}
	if (suma_konrotlna == 0)
		return true;
	else
	{
		for (int i = 0; i < bok; i++)
			a[i].x++;
		return false;
	}
}

bool check_collison_right(Punkt* tab, int* POLE_GRY, Punkt offset)
{
	int suma_konrotlna = 0;
	for (int i = 0; i < bok; i++)
	{
		Punkt punkt_globalny = { a[i].x + offset.x, a[i].y + offset.y };
		if (POLE_GRY[(punkt_globalny.y) * SZER_MARG + punkt_globalny.x] != 8)
			suma_konrotlna++;
	}
	if (suma_konrotlna == 0)
		return true;

	else
	{
		for (int i = 0; i < bok; i++)
			a[i].x--;
		return false;
	}
}

bool check_collision_bottom(Punkt* tab, int* POLE_GRY, Punkt offset)
{
	int suma_konrotlna = 0;
	for (int i = 0; i < bok; i++)
	{
		Punkt punkt_globalny = { a[i].x + offset.x, a[i].y + offset.y };
		if (POLE_GRY[(punkt_globalny.y) * SZER_MARG + punkt_globalny.x] != 8)
			suma_konrotlna++;
	}
	if (suma_konrotlna == 0)
		return true;

	else
	{
		for (int i = 0; i < bok; i++)
			a[i].y--;
		return false;
	}

}

bool check_if_game_over(int* POLE_GRY)
{
	for (int i = 1; i < SZER_MARG - 1; i++)
		if (POLE_GRY[3 * SZER_MARG + i] != 8)
			return true;
	return false;
}

void erase_line(int indeks_wiersza, int* POLE_GRY)
{
	for (int j = indeks_wiersza; j > 0; j--)
	{
		for (int i = 1; i < SZER_MARG - 1; i++)
		{
			POLE_GRY[j * SZER_MARG + i] = POLE_GRY[(j - 1) * SZER_MARG + i];
		}
	}
}

void make_new_piece()
{
	offset.x = 4;
	offset.y = 0;
	int temp = dist(gen);
	int indeks = 0;
	while (temp == n)
		temp = dist(gen);
	n = temp;
	for (int i = 0; i < bok; i++)
	{
		for (int j = 0; j < bok; j++)
		{
			if (tetromino[n][i * bok + j] == 1)
			{
				a[indeks].x = j;
				a[indeks].y = i;
				indeks++;
			}

		}
	}	
}

void clear_game_field(int* POLE_GRY, int& obecne_punkty, Punkt& offset)
{
	for (int i = 0; i < SZER_MARG; i++)
		for (int j = 0; j < WYS_MARG; j++)
			POLE_GRY[SZER_MARG * j + i] = (i == 0 || i == SZER_MARG - 1 || j == WYS_MARG - 1) ? 9 : 8;
	obecne_punkty = 0;
	offset.x = 4;
	offset.y = 0;
}

int obecne_punkty = 0;

int main()
{
	// Renderowanie okna
	RenderWindow window(VideoMode(640, 480), "Tetris Marcinka");

	// Wczytywanie tekstur klocków
	Texture t;
	t.loadFromFile("Tetris.png");
	Sprite s(t);

	// Wczytanie tekstury ramki
	Sprite rama(t);
	rama.setTextureRect(IntRect(133, 0, 19, 19));

	// Wczytywanie tła gry
	Texture background;
	background.loadFromFile("background.png");
	Sprite bgnd(background);
	bgnd.setPosition(19, 0);

	// Mierzenie czasu
	Clock clock;
	float timer = 0;
	float timestep = 0.3;


	int* POLE_GRY = new int[WYS_MARG * SZER_MARG];
	for (int i = 0; i < SZER_MARG; i++)
		for (int j = 0; j < WYS_MARG; j++)
			POLE_GRY[SZER_MARG * j + i] = (i == 0 || i == SZER_MARG - 1 || j == WYS_MARG - 1) ? 9 : 8;

	Font font;
	if (!font.loadFromFile("Fonts/arial.ttf"))
	{
		std::cout << "Cannot read font" << std::endl;
		system("pause");
		return 1;
	}


	Text text;
	text.setFont(font);
	text.setPosition(14 * 19, 2 * 19);
	text.setCharacterSize(50);
	text.setFillColor(Color::Black);

	Text instrukcje;
	instrukcje.setFont(font);
	instrukcje.setPosition(14 * 19, 8 * 19);
	instrukcje.setCharacterSize(24);
	instrukcje.setFillColor(Color::Black);
	instrukcje.setString("R - Restart\nP - Pause");

	bool rotate = false,
		move_left = false,
		move_right = false,
		move_down = false,
		game_over = false,
		pause_game = false;

	make_new_piece();

	Event event;
	while (window.isOpen())
	{
		float time = clock.getElapsedTime().asSeconds();
		clock.restart();
		timer += time;

		while (window.pollEvent(event))
		{

			if (event.type == Event::Closed)
			{
				window.close();
			}
			if (event.type == Event::KeyPressed)
			{
				if (event.key.code == Keyboard::R)
				{
					if (game_over)
					{
						game_over = false;
						clear_game_field(POLE_GRY, obecne_punkty, offset);
						pause_game = false;
					}
					else
					{
						clear_game_field(POLE_GRY, obecne_punkty, offset);
						make_new_piece();
						pause_game = false;
					}
				}
				else if (event.key.code == Keyboard::Up)
				{
					rotate = true;
				}
				else if (event.key.code == Keyboard::Left)
				{
					move_left = true;
				}
				else if (event.key.code == Keyboard::Right)
				{
					move_right = true;
				}
				else if (event.key.code == Keyboard::P)
				{
					if (!pause_game)
					{
						pause_game = true;
						rotate = false;
						move_down = false;
						move_left = false;
						move_right = false;
					}
					else
					{
						pause_game = false;
						rotate = false;
						move_down = false;
						move_left = false;
						move_right = false;
					}
				}
				/*else if (event.key.code == Keyboard::O)
				{
					RenderWindow okno2(VideoMode(200, 150), "okno2");
					Event event2;
					sf::String playerInput;
					sf::Text playerText;
					while (okno2.isOpen())
					{
						while (okno2.pollEvent(event2))
						{
							if (event2.type == Event::Closed)
							{
								okno2.close();
							}
							if (event2.type == Event::TextEntered)
							{
								playerInput += event2.text.unicode;
								playerText.setString(playerInput);
							}
						}
						okno2.clear(Color::White);
						playerText.setPosition(10, 10);
						playerText.setFont(font);
						playerText.setCharacterSize(10);
						playerText.setFillColor(Color::Black);
						okno2.draw(playerText);
						okno2.display();
					}
				}*/
			}
		}


		window.clear(Color::White);
		window.draw(bgnd);
		for (int i = 0; i < SZER_MARG; i++)
			for (int j = 0; j < WYS_MARG; j++)
			{
				if (POLE_GRY[SZER_MARG * j + i] == 9)
				{
					rama.setPosition(i * 19, (j - 4) * 19);
					window.draw(rama);
				}
				if (POLE_GRY[SZER_MARG * j + i] >= 0 && POLE_GRY[SZER_MARG * j + i] <= 6)
				{
					s.setPosition(i * 19, (j - 4) * 19);
					s.setTextureRect(IntRect(POLE_GRY[SZER_MARG * j + i] * 19, 0, 19, 19));
					window.draw(s);
				}
			}

		int ilosc_linii = 0;

		if (!game_over)
		{
			s.setTextureRect(IntRect(n * 19, 0, 19, 19));

			if (!pause_game)
			{
				if (rotate)
				{

					Punkt pivot = a[2];
					Punkt pomoc;
					Punkt odwrocony[4];
					for (int i = 0; i < bok; i++)
					{
						pomoc.x = -(a[i].y - pivot.y);
						pomoc.y = a[i].x - pivot.x;
						odwrocony[i].x = pomoc.x + pivot.x;
						odwrocony[i].y = pomoc.y + pivot.y;
					}
					int suma_kontrolna = 0;
					for (int i = 0; i < bok; i++)
					{
						if (POLE_GRY[(odwrocony[i].y + offset.y) * SZER_MARG + (odwrocony[i].x + offset.x)] != 8)
							suma_kontrolna++;
					}
					if (suma_kontrolna == 0)
					{
						for (int i = 0; i < bok; i++)
						{
							a[i].x = odwrocony[i].x;
							a[i].y = odwrocony[i].y;
						}
					}
					rotate = false;
				}

				if (move_left)
				{
					for (int i = 0; i < bok; i++)
						a[i].x--;
					check_collison_left(a, POLE_GRY, offset);
					move_left = false;
				}

				if (move_right)
				{
					for (int i = 0; i < bok; i++)
						a[i].x++;
					check_collison_right(a, POLE_GRY, offset);
					move_right = false;
				}

				if (Keyboard::isKeyPressed(Keyboard::Down))
					timestep = 0.05;
				else
					timestep = 0.3;

				if (timer > timestep)
				{
					for (int i = 0; i < bok; i++)
						a[i].y++;
					if (!check_collision_bottom(a, POLE_GRY, offset))
					{
						for (int i = 0; i < bok; i++)
						{
							POLE_GRY[(offset.y + a[i].y) * SZER_MARG + offset.x + a[i].x] = n;
						}
						make_new_piece();
					}
					timer = 0;
				}

				if (check_if_game_over(POLE_GRY))
				{
					game_over = true;
					continue;
				}

				// sprawdzanie pełnych linii
				for (int j = 0; j < WYS_MARG - 1; j++)
				{
					int licznik = 0;
					int i = 1;
					for (i; i < SZER_MARG - 1; i++)
					{
						if (POLE_GRY[j * SZER_MARG + i] == 8)
							licznik++;
					}
					if (licznik == 0)
					{
						ilosc_linii++;
						erase_line(j, POLE_GRY);
					}
				}
			}
			obecne_punkty += (ilosc_linii * ilosc_linii) * 100;	//dodatkowe punkty za większą ilość linii

			text.setString("Score: " + std::to_string(obecne_punkty));	// wyświetlenie obecnej ilości punktów
			window.draw(text);
			window.draw(instrukcje);

			for (int i = 0; i < bok; i++)
			{
				s.setPosition((offset.x + a[i].x) * 19, (offset.y + a[i].y - 4) * 19);
				window.draw(s);
			}
		}
		else
		{
			obecne_punkty += (ilosc_linii * ilosc_linii) * 100;	//dodatkowe punkty za większą ilość linii

			text.setString("Score: " + std::to_string(obecne_punkty));	// wyświetlenie obecnej ilości punktów
			window.draw(text);
			window.draw(instrukcje);

			for (int i = 0; i < bok; i++)
			{
				s.setPosition((offset.x + a[i].x) * 19, (offset.y + a[i].y - 4) * 19);
				window.draw(s);
			}

			RectangleShape rect(Vector2f(12 * 19 - 8, 8 * 19 - 4));
			rect.setPosition(4, 6 * 19);
			rect.setFillColor(Color(90, 154, 231, 235));
			rect.setOutlineColor(Color::Black);
			rect.setOutlineThickness(4);
			window.draw(rect);

			Text text_game_over;
			text_game_over.setCharacterSize(25);
			text_game_over.setFillColor(Color::Black);
			text_game_over.setFont(font);
			text_game_over.setPosition(50, 7 * 19);
			text_game_over.setString("Game over!\nPress R to \nstart again");
			window.draw(text_game_over);
		}

		window.display();
	}

	delete[] POLE_GRY;
	return 0;
}
